
Custom Product Reviews - Fixed (v1.1.0)
=======================================

This fixed plugin ensures shortcodes render correctly and AJAX nonces match between PHP and JS.

Shortcodes:
- [cpr_review_form]  - shows the review submission form. Automatically sets product_id to current post if not provided.
- [cpr_review_list]  - shows reviews for the product and filter controls.

How to use:
1. Install plugin via Upload Plugin or unzip to wp-content/plugins/
2. Activate plugin
3. Add [cpr_review_form] to your Write a Review page
4. Add [cpr_review_list] to your product page or product template
5. Approve reviews in WP Admin -> Product Reviews

Notes:
- AJAX nonce is 'cpr_nonce_fixed' and is localized to the script. If you cache JS, clear cache.
- If reviews don't appear, ensure reviews are approved in Admin (status 'publish').
- For WooCommerce verified-buyer integration or Figma pixel-perfect design polish, ask me to add those features next.
