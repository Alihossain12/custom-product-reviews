jQuery(document).ready(function($){
    // use delegated submit handler to ensure form exists
    $(document).on('submit','#cpr-review-form', function(e){
        e.preventDefault();
        var $form = $(this);
        var fd = new FormData(this);

        // include nonce from localized object if not present
        if(typeof cpr_ajax !== 'undefined' && cpr_ajax.nonce){
            fd.set('nonce', cpr_ajax.nonce);
        }

        $.ajax({
            url: cpr_ajax.ajax_url,
            method: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            success: function(res){
                if(res.success){
                    $('#cpr-message').text(res.data);
                    $form[0].reset();
                    // reload reviews if list present
                    var list = $('#cpr-review-list');
                    if(list.length) {
                        var pid = list.data('product-id');
                        $.post(cpr_ajax.ajax_url, {action:'cpr_get_reviews_fixed', product_id: pid}, function(resp){ if(resp.success) list.html(resp.data.html); });
                    }
                } else {
                    $('#cpr-message').text(res.data || 'Submission failed');
                }
            },
            error: function(){ $('#cpr-message').text('Submission failed (network).'); }
        });
    });

    // Filters
    function loadReviews(){
        var container = $('#cpr-review-list');
        if(!container.length) return;
        var pid = container.data('product-id');
        var rating = $('#cpr-filter-rating').val();
        var age = $('#cpr-filter-age').val();
        var s = $('#cpr-search').val();
        $.post(cpr_ajax.ajax_url, {action:'cpr_get_reviews_fixed', product_id: pid, rating: rating, age: age, s: s}, function(resp){
            if(resp.success) container.html(resp.data.html);
        });
    }
    $('#cpr-filter-rating, #cpr-filter-age').on('change', loadReviews);
    $('#cpr-search').on('input', function(){ setTimeout(loadReviews, 200); });
    loadReviews();
});