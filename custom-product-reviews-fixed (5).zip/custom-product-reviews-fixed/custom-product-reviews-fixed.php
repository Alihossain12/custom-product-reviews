<?php
/**
 * Plugin Name: Custom Product Reviews
 * Description: Fixed & improved plugin.
 * Version: 1.1.0
 * Author: Ali hossain
 */

if(!defined('ABSPATH')) exit;

class CPR_Fixed {
    const CPT = 'product_review_fixed';

    public function __construct(){
        add_action('init', [$this,'register_cpt']);
        add_action('init', [$this,'register_shortcodes']);
        add_action('wp_enqueue_scripts', [$this,'frontend_assets']);
        add_action('admin_enqueue_scripts', [$this,'admin_assets']);

        add_action('wp_ajax_nopriv_cpr_submit_fixed', [$this,'ajax_submit']);
        add_action('wp_ajax_cpr_submit_fixed', [$this,'ajax_submit']);
        add_action('wp_ajax_cpr_get_reviews_fixed', [$this,'ajax_get_reviews']);

        add_action('admin_menu', [$this,'admin_menu']);
        add_action('admin_post_cpr_approve_fixed', [$this,'admin_approve']);
        add_action('admin_post_cpr_reject_fixed', [$this,'admin_reject']);
    }

    public function register_cpt(){
        $labels = ['name'=>'Product Reviews','singular_name'=>'Product Review'];
        register_post_type(self::CPT, [
            'labels'=>$labels,
            'public'=>false,
            'show_ui'=>true,
            'supports'=>['title','editor','author'],
        ]);
    }

    public function register_shortcodes(){
        add_shortcode('cpr_review_form', [$this,'shortcode_form']);
        add_shortcode('cpr_review_list', [$this,'shortcode_list']);
    }

    public function frontend_assets(){
        // register and enqueue styles and scripts
        wp_register_style('cpr_fixed_frontend', plugins_url('assets/css/frontend.css', __FILE__));
        wp_register_script('cpr_fixed_frontend', plugins_url('assets/js/frontend.js', __FILE__), ['jquery'], false, true);

        wp_localize_script('cpr_fixed_frontend', 'cpr_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cpr_nonce_fixed')
        ]);

        wp_enqueue_style('cpr_fixed_frontend');
        wp_enqueue_script('cpr_fixed_frontend');
    }

    public function admin_assets(){
        wp_enqueue_style('cpr_fixed_admin', plugins_url('assets/css/admin.css', __FILE__));
    }

    public function shortcode_form($atts){
        $atts = shortcode_atts(['product_id' => get_the_ID()], $atts);
        ob_start(); ?>
        <form id="cpr-review-form" class="cpr-form" enctype="multipart/form-data">
            <input type="hidden" name="action" value="cpr_submit_fixed">
            <input type="hidden" name="product_id" value="<?php echo esc_attr($atts['product_id']); ?>">
            <input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('cpr_nonce_fixed')); ?>">

            <input name="review_title" placeholder="Review Title" required />
            <textarea name="review_description" placeholder="Review Description" required></textarea>

            <label>Star Rating
                <select name="review_rating" required>
                    <option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1</option>
                </select>
            </label>

            <label>Upload (JPG/PNG/PDF)
                <input type="file" name="review_file" accept=".jpg,.jpeg,.png,.pdf" />
            </label>

            <div class="social-ui">
                <button type="button" class="social-btn">Continue with Facebook</button>
                <button type="button" class="social-btn">Continue with Google</button>
            </div>

            <input name="review_name" placeholder="Name" required />
            <input name="review_email" placeholder="Email" required />
            <label>Age Range
                <select name="review_age_range">
                    <option value="">Choose one</option>
                    <option>Under 18</option><option>18-24</option><option>25-34</option><option>35-44</option><option>45-54</option><option>55-64</option><option>65+</option>
                </select>
            </label>

            <label><input type="checkbox" name="agree_terms" value="1" required /> By continuing you agree to Terms & Conditions</label>

            <button type="submit" class="cpr-submit">Agree & Submit</button>
            <div id="cpr-message" role="status" aria-live="polite"></div>
        </form>
        <?php
        return ob_get_clean();
    }

    public function shortcode_list($atts){
        $atts = shortcode_atts(['product_id' => get_the_ID()], $atts);
        ob_start(); ?>
        <div class="cpr-filters">
            <input id="cpr-search" placeholder="Search reviews..." />
            <select id="cpr-filter-rating"><option value="">All ratings</option><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select>
            <select id="cpr-filter-age"><option value="">All ages</option><option>Under 18</option><option>18-24</option><option>25-34</option><option>35-44</option><option>45-54</option><option>55-64</option><option>65+</option></select>
        </div>
        <div id="cpr-review-list" data-product-id="<?php echo esc_attr($atts['product_id']); ?>">
            <?php echo $this->render_reviews($atts['product_id']); ?>
        </div>
        <?php return ob_get_clean();
    }

    public function ajax_submit(){
        // nonce verify
        $nonce = $_POST['nonce'] ?? '';
        if(!wp_verify_nonce($nonce, 'cpr_nonce_fixed')) wp_send_json_error('Invalid nonce.');

        $product_id = intval($_POST['product_id'] ?? 0);
        $title = sanitize_text_field($_POST['review_title'] ?? '');
        $desc = sanitize_textarea_field($_POST['review_description'] ?? '');
        $rating = intval($_POST['review_rating'] ?? 0);
        $name = sanitize_text_field($_POST['review_name'] ?? '');
        $email = sanitize_email($_POST['review_email'] ?? '');
        $age = sanitize_text_field($_POST['review_age_range'] ?? '');
        $agree = isset($_POST['agree_terms']) ? 1 : 0;

        if(!$agree) wp_send_json_error('You must agree to terms.');
        if(!$email || !is_email($email)) wp_send_json_error('Invalid email.');
        if($rating < 1 || $rating > 5) wp_send_json_error('Invalid rating.');

        $post_id = wp_insert_post([ 'post_type'=>self::CPT, 'post_title'=>$title?:'Untitled review', 'post_content'=>$desc, 'post_status'=>'pending' ]);
        if(is_wp_error($post_id)) wp_send_json_error('Could not save review.');

        update_post_meta($post_id,'_review_rating',$rating);
        update_post_meta($post_id,'_review_name',$name);
        update_post_meta($post_id,'_review_email',$email);
        update_post_meta($post_id,'_review_age_range',$age);
        update_post_meta($post_id,'_review_product_id',$product_id);

        // file upload (safe handling)
        if(!empty($_FILES['review_file']['name'])){
            require_once(ABSPATH.'wp-admin/includes/file.php');
            $overrides = ['test_form'=>false, 'mimes'=>['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','pdf'=>'application/pdf']];
            $uploaded = wp_handle_upload($_FILES['review_file'],$overrides);
            if(empty($uploaded['error'])){
                $file = $uploaded['file'];
                $filetype = wp_check_filetype(basename($file), null);
                $attachment = ['post_mime_type'=>$filetype['type'],'post_title'=>sanitize_file_name(basename($file)),'post_status'=>'inherit'];
                $attach_id = wp_insert_attachment($attachment,$file,$post_id);
                require_once(ABSPATH.'wp-admin/includes/image.php');
                $attach_data = wp_generate_attachment_metadata($attach_id,$file);
                wp_update_attachment_metadata($attach_id,$attach_data);
                update_post_meta($post_id,'_review_file',$attach_id);
            }
        }

        // trigger hook for additional processing
        do_action('cpr_after_save_fixed', $post_id);

        wp_send_json_success('Review submitted and pending approval.');
    }

    public function render_reviews($product_id, $args=[]){
        $meta_query = [['key'=>'_review_product_id','value'=>$product_id,'compare'=>'=']];
        if(!empty($args['rating'])) $meta_query[] = ['key'=>'_review_rating','value'=>intval($args['rating']),'compare'=>'=','type'=>'NUMERIC'];
        if(!empty($args['age'])) $meta_query[] = ['key'=>'_review_age_range','value'=>$args['age'],'compare'=>'='];
        $q = new WP_Query(['post_type'=>self::CPT,'post_status'=>'publish','meta_query'=>$meta_query,'posts_per_page'=>50,'s'=>($args['s'] ?? '')]);
        if(!$q->have_posts()) return '<p class="cpr-no-reviews">No reviews found.</p>';
        ob_start();
        while($q->have_posts()): $q->the_post();
            $id = get_the_ID();
            $name = get_post_meta($id,'_review_name',true)?:'Anonymous';
            $rating = intval(get_post_meta($id,'_review_rating',true));
            $age = get_post_meta($id,'_review_age_range',true);
            $file_id = get_post_meta($id,'_review_file',true);
            $date = get_the_date();
            ?>
            <div class="cpr-review-item">
                <div class="cpr-review-head"><strong><?php echo esc_html($name);?></strong> <span class="cpr-badge">Verified Buyer</span> <span class="cpr-stars"><?php echo esc_html(str_repeat('★',$rating));?></span></div>
                <div class="cpr-meta">Age: <?php echo esc_html($age); ?> — <?php echo esc_html($date);?></div>
                <div class="cpr-content"><?php echo wp_kses_post(get_the_content());?></div>
                <?php if($file_id){ $url = wp_get_attachment_url($file_id); echo '<div class="cpr-file"><a href="'.esc_url($url).'" target="_blank">View attachment</a></div>'; } ?>
            </div>
            <?php
        endwhile; wp_reset_postdata();
        return ob_get_clean();
    }

    public function ajax_get_reviews(){
        $product_id = intval($_POST['product_id'] ?? 0);
        $rating = isset($_POST['rating']) && $_POST['rating'] !== '' ? intval($_POST['rating']) : 0;
        $age = sanitize_text_field($_POST['age'] ?? '');
        $s = sanitize_text_field($_POST['s'] ?? '');
        $args = ['rating'=>$rating,'age'=>$age,'s'=>$s];
        $html = $this->render_reviews($product_id,$args);
        wp_send_json_success(['html'=>$html]);
    }

    public function admin_menu(){
        add_menu_page('Product Reviews','Product Reviews','manage_options','cpr_reviews_fixed',[$this,'admin_page'],'dashicons-star-filled',26);
    }

    public function admin_page(){
        if(!current_user_can('manage_options')) return;
        $tab = $_GET['tab'] ?? 'pending';
        $status = $tab === 'published' ? 'publish' : 'pending';
        $q = new WP_Query(['post_type'=>self::CPT,'post_status'=>$status,'posts_per_page'=>100]);
        ?>
        <div class="wrap"><h1>Product Reviews</h1>
        <h2 class="nav-tab-wrapper"><a class="nav-tab <?php echo $tab==='pending'?'nav-tab-active':'';?>" href="?page=cpr_reviews_fixed&tab=pending">Pending</a><a class="nav-tab <?php echo $tab==='published'?'nav-tab-active':'';?>" href="?page=cpr_reviews_fixed&tab=published">Published</a></h2>
        <table class="widefat fixed"><thead><tr><th>Title</th><th>Reviewer</th><th>Rating</th><th>Product</th><th>Date</th><th>Actions</th></tr></thead><tbody>
        <?php if($q->have_posts()): while($q->have_posts()): $q->the_post(); $id=get_the_ID(); $name=get_post_meta($id,'_review_name',true); $rating=get_post_meta($id,'_review_rating',true); $product_id=get_post_meta($id,'_review_product_id',true); ?>
            <tr><td><?php echo esc_html(get_the_title());?></td><td><?php echo esc_html($name);?><br><?php echo esc_html(get_post_meta($id,'_review_email',true));?></td><td><?php echo esc_html($rating);?></td><td><?php echo esc_html($product_id);?></td><td><?php echo esc_html(get_the_date());?></td>
            <td><?php if(get_post_status($id)!=='publish'): ?>
                <form method="post" action="<?php echo admin_url('admin-post.php');?>"><?php wp_nonce_field('cpr_admin_fixed','cpr_admin_nonce');?><input type="hidden" name="action" value="cpr_approve_fixed"><input type="hidden" name="review_id" value="<?php echo esc_attr($id);?>"><button class="button button-primary">Approve</button></form>
            <?php endif; ?>
                <form method="post" action="<?php echo admin_url('admin-post.php');?>"><?php wp_nonce_field('cpr_admin_fixed','cpr_admin_nonce');?><input type="hidden" name="action" value="cpr_reject_fixed"><input type="hidden" name="review_id" value="<?php echo esc_attr($id);?>"><button class="button">Reject</button></form>
            </td></tr>
        <?php endwhile; wp_reset_postdata(); else: ?><tr><td colspan="6">No reviews found.</td></tr><?php endif; ?>
        </tbody></table></div>
        <?php
    }

    public function admin_approve(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        if(!isset($_POST['cpr_admin_nonce']) || !wp_verify_nonce($_POST['cpr_admin_nonce'],'cpr_admin_fixed')) wp_die('Invalid nonce');
        $id = intval($_POST['review_id'] ?? 0);
        if($id) wp_update_post(['ID'=>$id,'post_status'=>'publish']);
        wp_redirect(admin_url('admin.php?page=cpr_reviews_fixed&tab=published')); exit;
    }

    public function admin_reject(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        if(!isset($_POST['cpr_admin_nonce']) || !wp_verify_nonce($_POST['cpr_admin_nonce'],'cpr_admin_fixed')) wp_die('Invalid nonce');
        $id = intval($_POST['review_id'] ?? 0);
        if($id) wp_update_post(['ID'=>$id,'post_status'=>'trash']);
        wp_redirect(admin_url('admin.php?page=cpr_reviews_fixed&tab=pending')); exit;
    }
}

new CPR_Fixed();

